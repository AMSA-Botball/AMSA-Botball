#include <kipr/botball.h>

void moveForward(double distance, double speed){
// this will work only for distance in centimeters and at 300 speed, this method is set up for the create
    double multiplier1 = 10.35;
    distance *= multiplier1;
    int time = (int)(1000*distance/speed);
    create_drive_direct(speed, speed*1.07);
    msleep(time);
    create_drive_direct(0,0);
}


void moveBackward(double distance, int speed){
    // this will work only for distance in centimeters and at 100 speed, this method is set up for the create
    distance *= 10.35;
    int time = (int)(1000*distance/speed);
    create_drive_direct(-speed, -speed*1.075);
    msleep(time);
    create_drive_direct(0,0);
}


void turnLeft(double angle){
set_create_total_angle(0);
    while(1){
        if(get_create_total_angle()< angle*1.12){ 
            create_drive_direct(-50,50);
        }
        else{
            break;
        }
    }
}


void turnRight(double angle){ 
	set_create_total_angle(0);
    while(1){
        if(get_create_total_angle()> -angle*1.12){
            create_drive_direct(50,-50);
        }
        else{
            break;
        }
    }
}


void turnRight180(){
    set_create_total_angle(0);
    while(1){
        if(get_create_total_angle()> -180*1.14){
            create_drive_direct(50,-50);
        }
        else{
            break;
        }
	}
}



void turnRight45(){
	set_create_total_angle(0);
    while(1){
        if(get_create_total_angle()> -45*1.1){ 
            create_drive_direct(50,-50);
        }
        else{
            break;
        }
	}
}


void turnLeft180(){
    set_create_total_angle(0);
    while(1){
        if(get_create_total_angle()< 180*1.14){
            create_drive_direct(-50,50);
        }
        else{
            break;
        } 
    } 
}


void turnLeft45(){
    set_create_total_angle(0);
    while(1){
        if(get_create_total_angle()> -45*1.1){ 
            create_drive_direct(50,-50);
        }
        else{
            break;
        }
    }
}
