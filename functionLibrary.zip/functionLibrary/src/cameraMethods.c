#include <kipr/botball.h>

int findObject(int chanNum, int num){ 
	/*checks for an object in channel chanNum num times and counts -1 for not there and 1 for there.
		Returns 1 if count is greater than 0, returns 0 otherwise*/
    camera_open_black();
    int count = 0;
    
    int i = 0;
    for (i=0; i<num; i++){
        camera_update();
        if (get_object_count(chanNum) > 0){
            count++;
        }else{
            count-=1;
        }
    }
    
    if (count > 0){
        return 1;
    }else{
        return 0;
    }
}
