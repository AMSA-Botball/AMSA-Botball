#include <kipr/botball.h>
#include "createMethods.h"
#include "cameraMethods.h"

int main()
{
    create_connect();
    moveBackward(100, 300.0);
    create_disconnect();
    return 0;
}